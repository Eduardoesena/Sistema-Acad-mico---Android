package br.com.fabioclaret.sistemaacademico;

public class Funcionario extends Pessoa{

    public void marcarPresenca(){
        System.out.println("====================================");
        System.out.println("FUNCIONÁRIO ASSINA LIVRO DE PRESENÇA");
        System.out.println("====================================");
    }
}
