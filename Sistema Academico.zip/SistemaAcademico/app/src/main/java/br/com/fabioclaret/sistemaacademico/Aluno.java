package br.com.fabioclaret.sistemaacademico;

public class Aluno extends Pessoa{

    public void marcarPresenca(){
        System.out.println("=======================");
        System.out.println("ALUNO RESPONDE A CHAMADA");
        System.out.println("=======================");
    }
}
