package br.com.fabioclaret.sistemaacademico;

import android.content.Context;
import android.widget.Toast;

public class Professor extends Pessoa{

    public void marcarPresenca(){
        System.out.println("====================");
        System.out.println("PROFESSOR BATE PONTO");
        System.out.println("====================");
    }
}
